<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contagem de Produtos Caros</title>
</head>
<body>
    <h1>Produtos Caros</h1>
    <p>Quantidade de produtos caros: <?php echo $expensiveProductsCount; ?></p>
</body>
</html>