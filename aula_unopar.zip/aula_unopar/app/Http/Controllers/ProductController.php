<?php

namespace App\Http\Controllers;

use App\Models\Produto;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $produtos = Produto::all();
        return view('produtos.index', compact('produtos'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('produtos.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // $input = $request->all();
        // Produto::create($input);

        Produto::create([
            'nome' => $request->input('nome'),
            'preco' => $request->input('preco'),
        ]);

        return redirect('/produtos');
    }

    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        $produto = Produto::find($id);
        return view('produtos.show', compact('produto'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $produto = Produto::find($id);
        return view('produtos.edit', compact('produto'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $produto = Produto::find($id);

        $produto->update([
            'nome' => $request->input('nome'),
            'preco' => $request->input('preco'),
        ]);

        return redirect('/produtos');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $produto = Produto::find($id);
        $produto->delete();

        return redirect('/produtos');
    }
}

class ProductController {
    public function getExpensiveProductsCount() {
        $products = [
            ["name" => "Produto 1", "price" => 1500],
            ["name" => "Produto 2", "price" => 700],
            ["name" => "Produto 3", "price" => 1200],
            ["name" => "Produto 4", "price" => 900]
        ];

        $expensiveProductsCount = 0;

        foreach ($products as $product) {
            if ($this->isExpensive($product['price'])) {
                $expensiveProductsCount++;
            }
        }

        return $expensiveProductsCount;
    }

    private function isExpensive($price) {
        return $price > 1000;
    }
}